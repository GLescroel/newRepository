package GLescroel.myGames;

/**
 * le Main()
 * lance la partie !
 */
public class Main {
    public static void main(String[] args){

        Partie maPartie = new Partie();
        maPartie.startPartie();

    }
}
