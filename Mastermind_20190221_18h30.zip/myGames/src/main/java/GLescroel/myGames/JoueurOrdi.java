package GLescroel.myGames;

import java.util.Random;

public class JoueurOrdi extends Joueur {

    // CONSTRUCTOR
    public JoueurOrdi(String nomJoueur) {
        this.setEstHumain(false);
        this.setNomJoueur(nomJoueur);
        setCombinaisonTrouvee(false);
    }

    @Override
    protected String[] joueurChoisitCombiSecrete(int nbDigit) {
        String[] selectedString = new String[nbDigit];

        for(int i = 0 ; i < nbDigit; i++) {
            Random rand = new Random();
            int nbAleatoire = rand.nextInt(9 - 0 + 1) + 0;
            selectedString[i] = String.valueOf(nbAleatoire);
        }

        String affichage = "";
        for(int i = 0; i < nbDigit; i++)
            affichage += selectedString[i];
        System.out.println("(ordiValue : " + affichage + ")");

        return selectedString;
    }

    @Override
    protected String[] joueurProposeCombi(int nbDigit) {
        //TODO
        System.out.println("TODO");
        String[] toto = {"0","0","0","0"};
        return toto;
    }
}
