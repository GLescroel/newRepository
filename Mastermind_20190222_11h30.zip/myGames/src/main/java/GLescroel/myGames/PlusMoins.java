package GLescroel.myGames;


public class PlusMoins extends Jeu {

    String mode;
    int nbDigit;
    int nbEssai;

    JoueurOrdi ordi;
    JoueurHumain joueur;


    public PlusMoins (String nomJeu, JoueurHumain joueur, JoueurOrdi ordi, String mode, int nbDigit, int nbEssai) {
        super(nomJeu, joueur, ordi, mode, nbDigit, nbEssai);
        this.nomJeu = nomJeu;
        this.mode = mode;
        this.nbDigit = nbDigit;
        this.nbEssai = nbEssai;
        this.joueur = joueur;
        this.ordi = ordi;
    }

    public void runPlusMoins() {
        System.out.println("TODO");
    }


}
