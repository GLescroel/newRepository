package com.ocr.anthony;

import java.util.Scanner;

public class Order {

    public void runMenu()
    {

        int nbMenuToOrder = this.nbMenu();
        do {

            for(int i=1; i <= nbMenuToOrder; i++){

                int nbMenu = 0;
                do {
                    this.displayAvailableMenu();
                    Scanner sc = new Scanner(System.in);
                    nbMenu = sc.nextInt();
                    this.displaySelectedMenu(nbMenu);
                }while((nbMenu < 1) || (nbMenu > 3));

            boolean allSideEnable = false;
            if ((nbMenu == 1) || (nbMenu == 2))
                allSideEnable = true;
            int nbSide = 0;
            do {
                this.displayAvailableSides(allSideEnable);
                Scanner sc = new Scanner(System.in);
                nbSide = sc.nextInt();
                this.displaySelectedSide(nbSide, allSideEnable);
            }while ((nbSide < 1) || ((nbSide > 3) && (allSideEnable==true)) || ((nbSide > 2) && (allSideEnable==false)));

            if (nbMenu != 2) {
                int nbDrink = 0;
                do {
                    this.displayAvailableDrinks();
                    Scanner sc = new Scanner(System.in);
                    nbDrink = sc.nextInt();
                    this.displaySelectedDrink(nbDrink);
                }while((nbDrink < 0) || (nbDrink > 3));
            }
        }
            nbMenuToOrder = 1;
        }while (this.moreMenu() == true);

        System.out.println("Merci pour votre commande : Bonne dégustation !");
    }

    /**
     * ask user how many menus he wants to order.
     */

    public int nbMenu() {

        System.out.println("combien de menu souhaitez vous commander ?");
        Scanner sc = new Scanner(System.in);
        return sc.nextInt();

    }

    /**
     * ask user if wants more menus.
     */
    public boolean moreMenu() {

        System.out.println("Souhaitez commander un menu supplémentaire ? O/N");
        Scanner sc = new Scanner(System.in);
        String moreMenuResult = sc.next();

        if(moreMenuResult.equals("O"))
            return true;
        else
            return false;
    }

    /**
     * Display all available menus in the restaurant.
     */
    public void displayAvailableMenu() {

        System.out.println("Choix menu:");
        System.out.println("- 1 : poulet");
        System.out.println("- 2 : boeuf");
        System.out.println("- 3 : végétarien");
        System.out.println("Quel menu souhaitez vous ?");
    }
    /**
     * Display all available Sides in the menu.
     */
    public void displayAvailableSides(boolean allSideEnable)
    {

        System.out.println("Choix accompagnement:");

        if(allSideEnable == true)
        {
            System.out.println("- 1 : légumes frais");
            System.out.println("- 2 : frites");
            System.out.println("- 3 : riz");
        }
        else
        {
            System.out.println("- 1 : riz");
            System.out.println("- 2 : pas de riz");
        }

        System.out.println("Quel accompagnement souhaitez vous ?");
    }

    /**
     * Display all available drinks in the menu.
     */
    public void displayAvailableDrinks() {

        System.out.println("Choix boisson:");
        System.out.println("- 1 : eau plate");
        System.out.println("- 2 : eau gazeuse");
        System.out.println("- 3 : soda");
        System.out.println("Quelle boisson souhaitez vous ?");
    }
    /**
     * Display a selected menu.
     * @param nbMenu The selected menu.
     */
    public void displaySelectedMenu(int nbMenu) {

        switch (nbMenu)
        {
            case 1:
                System.out.println("Vous avez choisi le menu au poulet");
                break;
            case 2:
                System.out.println("Vous avez choisi le menu au boeuf");
                break;
            case 3:
                System.out.println("Vous avez choisi le menu végétarien");
                break;
            default:
                System.out.println("Votre saisie est incorrecte");
                break;
        }
    }


    public void displaySelectedSide(int nbSide, boolean allSideEnable)
    {
        if(allSideEnable)
        {
            switch (nbSide)
            {
                case 1:
                    System.out.println("Vous avez choisi comme accompagnement : légumes frais ");
                    break;
                case 2:
                    System.out.println("Vous avez choisi comme accompagnement : frites ");
                    break;
                case 3:
                    System.out.println("Vous avez choisi comme accompagnement : riz ");
                    break;
                default:
                    System.out.println("Vous n'avez choisi aucun accompagnement parmi les choix proposés");
                    break;
            }
        }
        else
        {
            switch (nbSide)
            {
                case 1:
                    System.out.println("Vous avez choisi comme accompagnement : riz ");
                    break;
                case 2:
                    System.out.println("Vous avez choisi comme accompagnement : pas de riz ");
                    break;
                default:
                    System.out.println("Vous n'avez choisi aucun accompagnement parmi les choix proposés");
                    break;
            }
        }
    }

    public void displaySelectedDrink(int nbDrink)
    {
        switch (nbDrink)
        {
            case 1:
                System.out.println("Vous avez choisi comme boisson : eau plate ");
                break;
            case 2:
                System.out.println("Vous avez choisi comme boisson : eau gazeuse ");
                break;
            case 3:
                System.out.println("Vous avez choisi comme boisson : soda ");
                break;
            default:
                System.out.println("Vous n'avez choisi aucune boisson parmi les choix proposés");
                break;
        }
    }
}