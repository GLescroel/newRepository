package GLescroel.myGames;

public class Main {
    public static void main(String[] args){

        Partie maPartie = new Partie();
        maPartie.startPartie();

    }
}
