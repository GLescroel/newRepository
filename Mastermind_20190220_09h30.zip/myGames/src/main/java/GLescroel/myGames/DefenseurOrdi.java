package GLescroel.myGames;

public class DefenseurOrdi extends Joueur implements Defenseur{

    @Override
    public void choisirCombinaisonSecrete(){
        System.out.println("Le défenseur ordi choisit sa combinaison");
    }

    @Override
    public void evaluerProposition(){
        System.out.println("evaluation par le defenseur Ordi de la combinaison proposée par l'attaquant humain");
    }

}
