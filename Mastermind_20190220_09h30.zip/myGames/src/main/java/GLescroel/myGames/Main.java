package GLescroel.myGames;

public class Main {
    public static void main(String[] args){


        Jeu monJeu = new Jeu();
        monJeu.initJeu();
        monJeu.startJeu();
        monJeu.runJeu();


    }
}
