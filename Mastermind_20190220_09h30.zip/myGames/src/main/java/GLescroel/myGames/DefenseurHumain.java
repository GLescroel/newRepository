package GLescroel.myGames;

public class DefenseurHumain extends Joueur implements Defenseur{

    @Override
    public void choisirCombinaisonSecrete(){
        System.out.println("Le défenseur humain choisit sa combinaison");
    }

    @Override
    public void evaluerProposition(){
        System.out.println("evaluation par le defenseur humain de la combinaison proposée par l'attaquant Ordi");
    }

}
