package GLescroel.myGames;

public class ChallengerHumain extends Joueur implements Challenger
{
    @Override
    public void proposerCombinaison(){
        System.out.println("Le challenger humain propose une combinaison");
    }

}
