package GLescroel.myGames;

public interface Challenger{

    public void proposerCombinaison();

}
