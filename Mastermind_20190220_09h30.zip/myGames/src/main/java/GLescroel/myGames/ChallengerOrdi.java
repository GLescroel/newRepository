package GLescroel.myGames;

public class ChallengerOrdi extends Joueur implements Challenger {

    @Override
    public void proposerCombinaison(){
        System.out.println("Le challenger ordi propose une combinaison");
    }
}
