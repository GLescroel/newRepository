package GLescroel.myGames;


public class Joueur {

    private String nomJoueur;
    private boolean estHumain;
    private boolean estDefenseur;






    public String getNomJoueur() {
        return nomJoueur;
    }

    public void setNomJoueur(String nomJoueur) {
        this.nomJoueur = nomJoueur;
    }

    public boolean isEstHumain() {
        return estHumain;
    }

    public void setEstHumain(boolean estHumain) {
        this.estHumain = estHumain;
    }

    public boolean isEstDefenseur() {
        return estDefenseur;
    }

    public void setEstDefenseur(boolean estDefenseur) {
        this.estDefenseur = estDefenseur;
    }

}
