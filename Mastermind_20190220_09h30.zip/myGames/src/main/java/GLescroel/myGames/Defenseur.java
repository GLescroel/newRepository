package GLescroel.myGames;

public interface Defenseur {

    public void choisirCombinaisonSecrete();
    public void evaluerProposition();

}
