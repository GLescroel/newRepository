package GLescroel.myGames;

import java.util.ArrayList;
import java.util.List;

public class Jeu {

    private String nomJeu;
    private String mode;
    private int nbEssai;
    private int nbDigit;
    private int nbJoueurs;

    public void InitJeu(){

        getNbJoueurs();
        initJeu();
        initJoueurs();

    }

    public void initJeu(){

        Initialisation initialisation = new Initialisation();
        initialisation.runInit();

        choisirJeu(initialisation.getJeuxPossibles());
        choisirMode(initialisation.getModesPossibles());
        choisirNbDigit(initialisation.getNbDigitMinPossible(), initialisation.getNbDigitMaxPossible());
        choisirNbEssai(initialisation.getNbEssaisMinPossible(), initialisation.getNbEssaisMaxPossible());
    }

    public void choisirJeu(List<String> listeJjeuxPossibles)
    {
        String[] jeuxPossibles = new String[listeJjeuxPossibles.size()];
        for(int j = 0 ; j < listeJjeuxPossibles.size() ; j++)
            jeuxPossibles[j] = listeJjeuxPossibles.get(j);

        int jeuChoisi = Interaction.askSomething("Jeu", jeuxPossibles)-1;
        nomJeu = listeJjeuxPossibles.get(jeuChoisi);

        //System.out.println("jeux choisi : " + nomJeu);
    }

    public void choisirMode(List<String> listeModesPossibles)
    {
        String[] modesPossibles = new String[listeModesPossibles.size()];
        for(int j = 0 ; j < listeModesPossibles.size() ; j++)
            modesPossibles[j] = listeModesPossibles.get(j);

        int modeChoisi = Interaction.askSomething("Mode", modesPossibles)-1;
        mode = listeModesPossibles.get(modeChoisi);

        //System.out.println("Mode choisi : " + mode);
    }

    public void choisirNbDigit(int nbDigitMin, int nbDigitMax)
    {
        nbDigit = Interaction.askQuantity("de digit", nbDigitMin, nbDigitMax);
    }

    public void choisirNbEssai(int nbEssaisMin, int nbEssaisMax)
    {
        nbEssai = Interaction.askQuantity("d'essais", nbEssaisMin, nbEssaisMax);
    }

    public void startJeu(){

        /*if((nbJoueurs == 1) && (mode.equals("Challenger"))
        {
            DefenseurOrdi ordi = new Joueur();
            Joueur joueur = new ChallengerHumain();
        }
        else if((nbJoueurs == 1) && (mode.equals("Defenseur"))
        {
            DefenseurOrdi ordi = new Defenseur();
            ChallengerHumain joueur = new Challenger();
        }*/

    }

    public void runJeu() {
    }

        public String getNomJeu() {
        return nomJeu;
    }

    public void setNomJeu(String nomJeu) {
        this.nomJeu = nomJeu;
    }

    public int getNbEssai() {
        return nbEssai;
    }

    public void setNbEssai(int nbEssai) {
        this.nbEssai = nbEssai;
    }

    public int getNbDigit() {
        return nbDigit;
    }

    public void setNbDigit(int nbDigit) {
        this.nbDigit = nbDigit;
    }

    public void getNbJoueurs(){
        nbJoueurs = Interaction.askQuantity("de joueurs humains", 0, 2);
    }

    public void initJoueurs(){

        if(nbJoueurs == 0)
        {
            Joueur ordi = new Joueur();
            ordi.setEstHumain(false);
            ordi.setNomJoueur("Ordi");

            if(mode.equals("Defenseur")){
                ordi.setEstDefenseur(true);
                System.out.println("L'ordinateur joue seul en défense");
            }
            else if (mode.equals("Challenger"))
                System.out.println("L'ordinateur joue seul en challenger");
            else
                System.out.println("L'ordinateur fait un duel contre lui même");

        }
        else if(nbJoueurs == 1) {
        System.out.println("toto");
        }
        else if(nbJoueurs == 2)
        {
            List<Joueur> joueurs = new ArrayList<>();
            for (int j = 0; j < nbJoueurs; j++)
            {
                Joueur joueur = new Joueur();
                joueur.setNomJoueur(Interaction.askText("prénom"));
                joueur.setEstHumain(true);

            }
        }
    }

}
