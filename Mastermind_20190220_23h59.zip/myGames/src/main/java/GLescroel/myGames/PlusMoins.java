package GLescroel.myGames;

public class PlusMoins extends Jeu {





}
