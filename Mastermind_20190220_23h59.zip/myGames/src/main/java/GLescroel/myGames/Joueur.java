package GLescroel.myGames;


public class Joueur {

    private String nomJoueur;
    private boolean estHumain;





    public String getNomJoueur() {
        return nomJoueur;
    }

    public void setNomJoueur(String nomJoueur) {
        this.nomJoueur = nomJoueur;
    }

    public boolean isHumain() {
        return estHumain;
    }

    public void setEstHumain(boolean estHumain) {
        this.estHumain = estHumain;
    }

}
