package myMastermind;

import org.junit.Test;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class GameTest {

    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();

    PrintStream ps = new PrintStream(outContent);
    PrintStream originalPrintStream = System.out;

    @BeforeEach
    public void setUpStreams() { System.setOut(new PrintStream(outContent)); }


    @AfterEach
    public void restoreStreams() {System.setOut(System.out);}



    @Test
    public void Given_Mastermind_When_CallingChooseGame_Then_DisplayMastermindSelected() {
        Game game = new Game();
        System.setIn(new ByteArrayInputStream("1\n".getBytes()));
//        assertEquals(1, game.chooseGame());
    }

    @Test
    public void Given_Plusminus_When_CallingChooseGame_Then_DisplayPlusMinusSelected() {
        Game game = new Game();
        System.setIn(new ByteArrayInputStream("2\n".getBytes()));
//        assertEquals(2, game.chooseGame());
    }

    @Test
    public void Given_Challenger_When_CallingChooseMode_Then_DisplayChallengerSelected() {
        Game game = new Game();
        System.setIn(new ByteArrayInputStream("1\n".getBytes()));
//        assertEquals(1, game.chooseMode());
    }

    @Test
    public void Given_Defenseur_When_CallingChooseMode_Then_DisplayDefenseurSelected() {
        Game game = new Game();
        System.setIn(new ByteArrayInputStream("2\n".getBytes()));
//        assertEquals(2, game.chooseMode());
    }

    @Test
    public void Given_Duel_When_CallingChooseMode_Then_DisplayDuelSelected() {
        System.setOut(ps);

        System.setIn(new ByteArrayInputStream("3\n".getBytes()));

        Game game = new Game();
        game.chooseMode();

        String[] output = outContent.toString().replace("\r\n", "\n").split("\n");

        System.out.println("toto1");
        System.out.println(outContent.toString());
        System.out.println("toto2");

        assertEquals("Vous avez choisi comme Mode : Duel", output[5]);

        System.setOut(originalPrintStream);
    }

    @Test
    public void Given_MastermindChallenger_When_CallingRunGame_Then_DisplayMastermindChallengerSelected() {
        System.setOut(ps);
        System.setIn(new ByteArrayInputStream(String.format("1%n1%n").getBytes()));

        Game game = new Game();
        game.runGame();

        String[] output = outContent.toString().replace("\r\n", "\n").split("\n");

        System.out.println(outContent.toString());
        assertEquals("Vous avez choisi comme Jeu : Mastermind%n" + "Vous avez choisi comme Mode : Challenger", output[0]);

        System.setOut(originalPrintStream);
    }

}
