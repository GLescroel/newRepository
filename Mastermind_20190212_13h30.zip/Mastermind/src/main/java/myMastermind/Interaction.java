package myMastermind;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Interaction {

    /**
     * Display a question about a category in the standard input, get response and display it
     * @param category  the category of the question
     * @param responses available responses
     */

    public static int askSomething(String category, String[] responses) {

        System.out.println("Choix du " + category);

        for (int i = 1; i <= responses.length; i++)
            System.out.println(i + " - " + responses[i - 1]);

        System.out.println("Que souhaitez vous comme " + category + "?");

        int responseNb=0;
        boolean responseIsGood = false;
        do {
            Scanner sc = new Scanner(System.in);
            try {
                responseNb = sc.nextInt();
                responseIsGood = (responseNb >= 1 && responseNb <= responses.length);
            }catch (InputMismatchException exception){
                System.out.println("Erreur de saisie");
                sc.next();
                responseIsGood = false;}

            /**if (nbResponse >= 1 && nbResponse <= responses.length)
             responseIsGood = true;
             else responseIsGood = false;*/

            if (responseIsGood == true)
                System.out.println("Vous avez choisi comme " + category + " : " + responses[responseNb - 1]);
            else {
                boolean isVowel = "aeiouy".contains(Character.toString(category.charAt(0)));
                if (isVowel)
                    System.out.println("Vous n'avez pas choisi d'" + category + " parmi les choix proposés");
                else
                    System.out.println("Vous n'avez pas choisi de " + category + " parmi les choix proposés");
            }
        } while (responseIsGood == false);

        return responseNb;
    }

    /**
     * Permet de récupérer le nombre saisi par le joueur pour une donnée
     * @param String requestedValue (nbCar ou nbTry), int minValue, int maxValue
     * @return le nombre saisi par le joueur
     */
    public static int askQuantity(String requestedValue, int minValue, int maxValue) {

        System.out.println("Choix du nombre " + requestedValue + " entre " + minValue + " et " + maxValue);
        System.out.println("Avec combien " + requestedValue + " souhaitez vous utiliser ?");

        int responseNb=0;
        boolean responseIsGood = false;
        do {
            Scanner sc = new Scanner(System.in);
            try {
                responseNb = sc.nextInt();
                responseIsGood = (responseNb >= minValue && responseNb <= maxValue);
            }catch (InputMismatchException exception){
                System.out.println("Erreur de saisie");
                sc.next();
                responseIsGood = false;}

            /**if (nbResponse >= 1 && nbResponse <= responses.length)
             responseIsGood = true;
             else responseIsGood = false;*/

            if (responseIsGood == true)
                System.out.println("Vous avez choisi comme quantité " + requestedValue + " : " + responseNb);
            else
                System.out.println("Vous n'avez pas choisi le nombre " + requestedValue + " parmi les choix proposés");
        } while (responseIsGood == false);

        return responseNb;
    }

    /**
     * Permet de récupérer la saisie du code secret du joueur
     * @param nbCar = longueur de la valeur secrète
     * @return the userSecretValue in String[]
     */
    public static String[] askUserASecretValue(int nbCar) {

        String[] enteredString = new String[nbCar];

        System.out.println("Saisissez une combinaison de " + nbCar + " chiffres : " );

        String responseNb="";
        boolean responseIsGood = false;
        do {
            Scanner sc = new Scanner(System.in);
            try {
                responseNb = sc.next();

                //System.out.println(responseNb);
                // compilation de la regex
                Pattern p = Pattern.compile("[0-9]{"+nbCar+"}");
                // création d'un moteur de recherche
                Matcher m = p.matcher(responseNb);
                // lancement de la recherche de toutes les occurrences
                responseIsGood = m.matches();
                // si recherche fructueuse
                if(responseIsGood) {
                    // pour chaque groupe (ici un seul possible car même longueur)
                    for(int i=0; i <= m.groupCount(); i++) {
                        // affichage de la sous-chaîne captu1rée
                        System.out.println("Votre saisie   : " + m.group(i));
                    }
                    for(int i=0; i <= (responseNb.length()-1); i++)
                        enteredString[i] = String.valueOf(responseNb.charAt(i));
                }else System.out.println("Votre saisie est incorrecte");

            }catch (InputMismatchException exception){
                System.out.println("Erreur de saisie");
                sc.next();
                responseIsGood = false;}

        } while (responseIsGood == false);

        return enteredString;
    }

    /**
     * Permet de positionner la valeur secrète aléatoire de l'ordinateur
     * @param nbCar = longueur de la valeur secrète
     * @return the ComputerSecretValue in String[]
     */
    public static String[] setComputerSecretValue(int nbCar) {
        String[] selectedString = new String[nbCar];

        for(int i = 0 ; i < nbCar; i++) {
            Random rand = new Random();
            int nbAleatoire = rand.nextInt(9 - 0 + 1) + 0;
            selectedString[i] = String.valueOf(nbAleatoire);
        }

        String affichage = "";
        for(int i = 0; i < nbCar; i++)
            affichage += selectedString[i];
        System.out.println("(ordiValue : " + affichage + ")");

        return selectedString;
    }


    public static boolean checkPlusMinusUser(String[] secretValue, String[] tryValue) {

        String tryResult = "";
        boolean allGood = true;
        for(int i = 0 ; i < tryValue.length; i++)
        {
            if(Integer.valueOf(secretValue[i].toString()) == Integer.valueOf(tryValue[i].toString()))
                tryResult += "=";
            else if(Integer.valueOf(secretValue[i].toString()) > Integer.valueOf(tryValue[i].toString()))
            {
                tryResult += "+";
                allGood = false;
            }
            else
            {
                tryResult += "-";
                allGood = false;
            }
        }

        System.out.println("Votre résultat : " + tryResult);

        return allGood;
    }

    public static boolean checkPlusMinusOrdi(String[] secretValue, String[] tryValue, String[] tryResult) {

        /*String aff = "";
        for(int i = 0; i < (tryValue.length); i++)
            aff += tryValue[i];
        System.out.println("test : " + aff + " length : " + (tryValue.length));*/

        boolean allGood = true;
        for(int i = 0 ; i < tryValue.length; i++)
        {
            if(Integer.valueOf(secretValue[i].toString()) == Integer.valueOf(tryValue[i].toString()))
                tryResult[i] = "=";
            else if(Integer.valueOf(secretValue[i].toString()) > Integer.valueOf(tryValue[i].toString()))
            {
                tryResult[i] = "+";
                allGood = false;
            }
            else
            {
                tryResult[i] = "-";
                allGood = false;
            }
        }

        String affichage = "";
        for(int i = 0; i < tryResult.length; i++)
            affichage += tryResult[i];
        System.out.println("Résultat  : " + affichage);

        return allGood;
    }

    public static String[] askComputerASecretValue(List<String[]> previousTry, String[] previousResult, int nbCar) {
        String[] selectedString = new String[nbCar];

        /*if(previousTry.size() == 0) {
            for(int i = 0; i < nbCar; i++)
                selectedString[i] = "5";
        }*/

        int minMax[] = {0,9};
        for (int i = 0; i < nbCar; i++) {
            if(previousTry.size() != 0) {
                if (previousResult[i] == "=") {
                    //selectedString[i] = (previousTry.get(previousTry.size()-1))[i];
                    minMax[0] = Integer.valueOf((previousTry.get(previousTry.size() - 1))[i]);
                    minMax[1] = Integer.valueOf((previousTry.get(previousTry.size() - 1))[i]);
                }
                else {
                    minMax = getMinMax(previousTry, previousResult[i], i);
                }
            }

            Random rand = new Random();
            //System.out.println("max : " + minMax[1] + " / min : " + minMax[0]);
            int nbAleatoire = rand.nextInt(minMax[1] - minMax[0] + 1) + minMax[0];
            selectedString[i] = String.valueOf(nbAleatoire);
        }


        String affichage = "";
        for(int i = 0; i < nbCar; i++)
            affichage += selectedString[i];
        System.out.println("ordiValue : " + affichage);

        return selectedString;

    }

    private static int[] getMinMax(List<String[]> previousTryList, String resultChar, int currentChar) {
        int min = 0;
        int max = 9;

        String[] previousTryChar= new String[previousTryList.size()];

        for (int prev = 0; prev < previousTryList.size(); prev++)
            previousTryChar[prev] = (previousTryList.get(prev)[currentChar]);

        /*String a = "";
        for(int z = 0; z < previousTryChar.length; z++)
            a += previousTryChar[z];
        System.out.println("tableau NON ordonné : " + a);*/

        boolean changed = false;
        do {
            changed = false;
            for (int prev = 1; prev < previousTryChar.length; prev++) {
                if ((Integer.valueOf(previousTryChar[prev])) < (Integer.valueOf(previousTryChar[prev-1]))) {
                    String inter = previousTryChar[prev];
                    previousTryChar[prev] = previousTryChar[prev-1];
                    previousTryChar[prev-1] = inter;
                    changed = true;
                }
            }
        } while(changed == true);

        /*a = "";
        for(int z = 0; z < previousTryChar.length; z++)
            a += previousTryChar[z];
        System.out.println("tableau ordonné : " + a);*/

        if(resultChar == "-") {
            if(previousTryChar.length == 1) //si premier test alors min = 0 et max = valeur testée
                min = 0;
            else
            {
                if(Integer.valueOf(previousTryChar[0]) >= Integer.valueOf((previousTryList.get(previousTryList.size()-1))[currentChar]))
                    min = 0; //si valeur testée plus petite que toutes les valeurs testées, min reste à zéro et max = valeur testée
                else {
                    for(int c = 0 ; c < (Integer.valueOf(previousTryChar.length)-1); c++)
                    {
                        if(((Integer.valueOf(previousTryChar[c]) + 1) != (Integer.valueOf(previousTryChar[c+1]))) //check si l'essai supérieur est déjà testée (pour ne pas tester 2 fois la même
                                && ((Integer.valueOf(previousTryChar[c])) <= (Integer.valueOf(((previousTryList.get(previousTryList.size()-1))[currentChar]))))) //check si la valeur min n'est pas inférieure à la valeur testée sur laquelle on doit proposer plus
                        {
                            min = Integer.valueOf(previousTryChar[c]) + 1;
                            //System.out.println("break min");
                            break;
                        }
                        else
                            min = Integer.valueOf(previousTryChar[0]) + 1;
                    }
                }
            }
            max = Integer.valueOf((previousTryList.get(previousTryList.size()-1))[currentChar]) -1;
        }
        else{
            min = Integer.valueOf((previousTryList.get(previousTryList.size()-1))[currentChar])+1;
            if(previousTryChar.length == 1) // si pas de test pr
                max = 9;
            else {
                if(Integer.valueOf(previousTryChar[previousTryChar.length - 1]) <= Integer.valueOf((previousTryList.get(previousTryList.size() - 1))[currentChar]))
                    max = 9;
                else {
                    for(int c = ((Integer.valueOf(previousTryChar.length)) -1) ; c > 0; c--)
                    {
                        if(((Integer.valueOf(previousTryChar[c]) - 1) != (Integer.valueOf(previousTryChar[c-1]))) &&
                                ((Integer.valueOf(previousTryChar[c])) >= Integer.valueOf((previousTryList.get(previousTryList.size()-1))[currentChar])))
                        {
                            max = Integer.valueOf(previousTryChar[c]) - 1;
                            //System.out.println("break max");
                            break;
                        }
                        else
                            max = Integer.valueOf(previousTryChar[previousTryChar.length-1]) - 1;
                    }
                }
            }
        }

        int[] minMax = {min, max};
        return minMax;


    }

    public static boolean checkMasterMindUser(String[] secretValue, String[] tryValue) {

        boolean allGood = true;
        int nbGood = 0;
        int nbPresent = 0;

        String secretValueString = "";
        for(int c = 0 ; c < secretValue.length ; c++)
            secretValueString += secretValue[c];

        for(int i = 0 ; i < tryValue.length; i++)
        {
            if(tryValue[i].equals(secretValue[i]))
                nbGood++;
            else if(secretValueString.contains(tryValue[i]))
            {
                nbPresent++;
                allGood = false;
            }
            else
                allGood = false;
        }

        System.out.println("Nb ok : " + nbGood + " \\ nb presents : " + nbPresent);

        return allGood;
    }
}
