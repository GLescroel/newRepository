package myMastermind;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Création de la classe Game
 */
public class Game {

    int game = 0;
    int mode = 0;
    int nbCar = 0;
    int nbTry = 0;

    String[] computerSecretValue = null;
    String[] userSecretValue = null;

    /**
     * permet de lancer un nouveau jeu
     * @see runSelectedGame()
     */

    public void runGame() {

        System.out.println("lancement du jeu !");

        this.gameSelection();
        this.initSecretValue();
        this.runSelectedGame();
    }

    /**
     * permet de lancer le type de jeu choisi dans le mode choisi
     * @param int jeu, int mode
     */
    public void gameSelection() {

        this.chooseGame();
        this.chooseMode();
        this.chooseNbCar();
        this.chooseNbTry();
    }

    /**
     * permet de choisir le type de jeu
     * @see Interaction.askSomething()
     */
    public void chooseGame() {

        String[] gameChoices = {"Mastermind", "+-+"};
        game = Interaction.askSomething("Jeu", gameChoices);
    }

    /**
     * permet de choisir le mode de jeu : challenger / défenseur / duel
     * @see Interaction.askSomething()
     */
    public void chooseMode() {

        String[] modeChoices = {"Challenger", "Défenseur", "Duel"};
        mode = Interaction.askSomething("Mode", modeChoices);
    }

    /**
     * permet de choisir le nombre de caractères
     * @see Interaction.askQuantity()
     */
    public void chooseNbCar() {
        nbCar = Interaction.askQuantity("de caractères", 4, 10);
    }

    /**
     * permet de choisir le nombre de tentatives
     * @see Interaction.askQuantity()
     */
    public void chooseNbTry() {
        nbTry = Interaction.askQuantity("d'essais", 3, 10);
    }


    /**
     * permet d'initialiser la ou les combinaisons secrètes en fonction du jeu et du mode
     * @param int jeu, int mode
     */
    private void initSecretValue() {

        if (mode == 2 || mode == 3) {
            System.out.println("Choix de votre valeur secrète de " + nbCar + " chiffres : ");
            userSecretValue = Interaction.askUserASecretValue(nbCar);
            String affichage = "";
            for(int i = 0 ; i < nbCar ; i++)
                affichage+=userSecretValue[i];
            System.out.println("Votre combinaison secrète : " + affichage);
        }

        if (mode == 1 || mode == 3)
            computerSecretValue = Interaction.setComputerSecretValue(nbCar);
    }


    /**
     * permet de lancer le jeu avec tous les critères définis
     */
    private void runSelectedGame() {

        boolean valueFoundByUser = false;
        boolean valueFoundByOrdi = false;

        List<String[]> TryList = new CopyOnWriteArrayList<String[]>();
        String[] previousResult = new String[nbCar];

        if(mode == 1) {
            if (game == 1) {
                int i = 1;
                do {
                    valueFoundByUser =  Interaction.checkMasterMindUser(computerSecretValue, Interaction.askUserASecretValue(nbCar));
                    i++;
                } while (i <= nbTry && valueFoundByUser == false);
            }
            if (game == 2) {
                int i = 1;
                do {
                    valueFoundByUser =  Interaction.checkPlusMinusUser(computerSecretValue, Interaction.askUserASecretValue(nbCar));
                    i++;
                } while (i <= nbTry && valueFoundByUser == false);
            }
        }
        if(mode == 2) {
            if (game == 1) {
                System.out.println("en cours de dev : revenez plus tard !");
                int i = 1;
                do {

                    //TryList.add(Interaction.askComputerASecretValue(TryList, previousResult, nbCar));
                    //valueFoundByOrdi =  Interaction.checkPlusMinusOrdi(userSecretValue, TryList.get(i-1), previousResult);
                    i++;
                } while (i <= nbTry && valueFoundByOrdi == false);
            }
            else if (game == 2) {

                int i = 1;
                do {

                    TryList.add(Interaction.askComputerASecretValue(TryList, previousResult, nbCar));
                    valueFoundByOrdi =  Interaction.checkPlusMinusOrdi(userSecretValue, TryList.get(i-1), previousResult);
                    i++;
                } while (i <= nbTry && valueFoundByOrdi == false);
            }
        }
        if(mode == 3){
            if (game == 1) {
                System.out.println("en cours de dev : revenez plus tard !");
                int i = 1;
                do {
                    //valueFoundByUser =  Interaction.checkMasterMindUser(computerSecretValue, Interaction.askUserASecretValue(nbCar));
                    //TryList.add(Interaction.askComputerASecretValue(TryList, previousResult, nbCar));
                    //valueFoundByOrdi =  Interaction.checkPlusMinusOrdi(userSecretValue, TryList.get(i-1), previousResult);
                    i++;
                } while (i <= (nbTry*2) && valueFoundByUser == false && valueFoundByOrdi == false);
            }
            if (game == 2) {
                int i = 1;
                do {
                    valueFoundByUser =  Interaction.checkPlusMinusUser(computerSecretValue, Interaction.askUserASecretValue(nbCar));
                    TryList.add(Interaction.askComputerASecretValue(TryList, previousResult, nbCar));
                    valueFoundByOrdi =  Interaction.checkPlusMinusOrdi(userSecretValue, TryList.get(i-1), previousResult);
                    i++;
                } while (i <= (nbTry*2) && valueFoundByUser == false && valueFoundByOrdi == false);
            }
        }

        if (valueFoundByUser == true && valueFoundByOrdi == true)
            System.out.println("égalité !");
        else if(valueFoundByOrdi == true)
            System.out.println("L'ordinateur a gagné !");
        else if (valueFoundByUser == true)
                System.out.println("Vous avez gagné !");
        else System.out.println("Vous avez perdu !");

    }



}