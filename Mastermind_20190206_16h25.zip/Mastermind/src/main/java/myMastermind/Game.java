package myMastermind;

public class Game {

    public void runGame() {

        System.out.println("lancement du jeu !");

        this.runSelectedGame(this.chooseGame(), this.chooseMode());

    }

    public void runSelectedGame(int game, int mode) {

    }

    public int chooseGame() {

        String[] game = {"Mastermind", "+-+"};
        return Interaction.askSomething("Jeu", game);
    }

    public int chooseMode() {

            String[] mode = {"Challenger", "Défenseur", "Duel"};
            return Interaction.askSomething("Mode", mode);
    }


}