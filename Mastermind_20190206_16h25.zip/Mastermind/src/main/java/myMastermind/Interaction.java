package myMastermind;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Interaction {

    /**
     * Display a question about a category in the standard input, get response and display it
     *
     * @param category  the category of the question
     * @param responses available responses
     */

    public static int askSomething(String category, String[] responses) {

        System.out.println("Choix du " + category);

        for (int i = 1; i <= responses.length; i++)
            System.out.println(i + " - " + responses[i - 1]);

        System.out.println("Que souhaitez vous comme " + category + "?");

        int responseNb=0;
        boolean responseIsGood = false;
        do {
            Scanner sc = new Scanner(System.in);
            try {
                responseNb = sc.nextInt();
                responseIsGood = (responseNb >= 1 && responseNb <= responses.length);
            }catch (InputMismatchException exception){
                System.out.println("Erreur de saisie");
                sc.next();
                responseIsGood = false;}

            /**if (nbResponse >= 1 && nbResponse <= responses.length)
             responseIsGood = true;
             else responseIsGood = false;*/

            if (responseIsGood == true)
                System.out.println("Vous avez choisi comme " + category + " : " + responses[responseNb - 1]);
            else {
                boolean isVowel = "aeiouy".contains(Character.toString(category.charAt(0)));
                if (isVowel)
                    System.out.println("Vous n'avez pas choisi d'" + category + " parmi les choix proposés");
                else
                    System.out.println("Vous n'avez pas choisi de " + category + " parmi les choix proposés");
            }
        } while (responseIsGood == false);

        return responseNb;
    }


}
